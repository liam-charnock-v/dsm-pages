import { useMemo } from "react";
import { CampaignStatusCard } from "./CampaignStatusCard";

interface Props {
  visible: boolean;
  onSwapFrame?: () => void;
}

function fmt(n: number) {
  return n.toLocaleString("en-US");
}

export function AvailabilityPanel({ visible, onSwapFrame }: Props) {
  const data = useMemo(() => {
    const frames = Math.floor(Math.random() * 430) + 60;
    const impressions = Math.floor(Math.random() * 1_400_000) + 350_000;
    const totalImpressions = Math.floor(impressions * (1.15 + Math.random() * 0.25));
    return { frames, impressions, totalImpressions };
  }, []);

  return (
    <div
      style={{
        position: "fixed",
        top: 76,
        right: 20,
        width: 316,
        zIndex: 40,
        transform: visible ? "translateX(0)" : "translateX(calc(100% + 28px))",
        opacity: visible ? 1 : 0,
        transition:
          "transform 0.42s cubic-bezier(0.32, 0.72, 0, 1), opacity 0.28s ease",
        pointerEvents: visible ? "auto" : "none",
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      {/* ── Availability card ── */}
      <div
        style={{
          backgroundColor: "#ebeefe",
          borderRadius: 12,
          padding: "8px 8px 8px 8px",
          boxShadow:
            "0px 4px 12px rgba(16,16,52,0.08), 0px 1px 3px rgba(16,16,52,0.06)",
        }}
      >
        {/* "AVAILABILITY" label */}
        <div style={{ padding: "0 4px 6px 4px" }}>
          <span
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: "var(--text-xs)",
              fontWeight: "var(--font-weight-medium)",
              color: "var(--accent)",
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              lineHeight: "20px",
            }}
          >
            Availability
          </span>
        </div>

        {/* ── Single unified white card ── */}
        <div
          style={{
            position: "relative",
            backgroundColor: "#ffffff",
            borderRadius: 10,
            overflow: "hidden",
          }}
        >
          {/* Border overlay */}
          <div
            aria-hidden="true"
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: 10,
              border: "1px solid rgba(19,18,33,0.08)",
              pointerEvents: "none",
              zIndex: 1,
            }}
          />

          {/* ── Frames row ── */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "14px 16px",
            }}
          >
            <span
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: "var(--text-sm)",
                fontWeight: "var(--font-weight-medium)",
                color: "var(--foreground)",
                lineHeight: "20px",
              }}
            >
              Frames
            </span>
            <span
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 24,
                fontWeight: 700,
                color: "var(--foreground)",
                lineHeight: "28px",
                letterSpacing: "-0.02em",
              }}
            >
              {fmt(data.frames)}
            </span>
          </div>

          {/* Divider */}
          <div
            style={{
              height: 1,
              backgroundColor: "rgba(19,18,33,0.07)",
              margin: "0 16px",
            }}
          />

          {/* ── Impressions row ── */}
          <div
            style={{
              padding: "14px 16px 12px 16px",
            }}
          >
            {/* Main row */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <span
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "var(--text-sm)",
                  fontWeight: "var(--font-weight-medium)",
                  color: "var(--foreground)",
                  lineHeight: "20px",
                }}
              >
                Impressions
              </span>
              <span
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 24,
                  fontWeight: 700,
                  color: "var(--foreground)",
                  lineHeight: "28px",
                  letterSpacing: "-0.02em",
                }}
              >
                {fmt(data.impressions)}
              </span>
            </div>

            {/* Total sub-row — right-aligned, muted */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
                gap: 5,
                marginTop: 3,
              }}
            >
              {/* Muted dot */}
              <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
                <circle cx="4" cy="4" r="4" fill="rgba(124,123,135,0.25)" />
              </svg>
              <span
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: "var(--text-xs)",
                  fontWeight: "var(--font-weight-normal)",
                  color: "var(--muted-foreground)",
                  lineHeight: "16px",
                }}
              >
                {fmt(data.totalImpressions)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ── Campaign Status card (12px gap comes from parent flex gap) ── */}
      <CampaignStatusCard />

      {/* ── Optimise card ── */}
      <div
        style={{
          backgroundColor: "#ffffff",
          borderRadius: 12,
          padding: 12,
          boxShadow: "0px 3px 4px 0px rgba(16,16,52,0.06), 0px 1px 2px 0px rgba(16,16,52,0.04)",
          border: "1px solid rgba(19,18,33,0.1)",
          display: "flex",
          flexDirection: "column",
          gap: 8,
        }}
      >
        <span
          style={{
            fontFamily: "'Inter', sans-serif",
            fontSize: "var(--text-xs)",
            fontWeight: "var(--font-weight-medium)",
            lineHeight: "16px",
            color: "var(--muted-foreground)",
            paddingLeft: 4,
          }}
        >
          Optimise Campaign
        </span>

        {/* Stacked link buttons */}
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {[
            { label: "Reshuffle Campaign", sub: "Reallocate all frames to better meet targets", action: undefined },
            { label: "Swap Frame", sub: "Replace a single underperforming frame", action: onSwapFrame },
          ].map(({ label, sub, action }, i, arr) => (
            <button
              key={label}
              onClick={action}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                width: "100%",
                padding: "8px 10px 8px 10px",
                backgroundColor: "transparent",
                border: "none",
                borderRadius: 8,
                outline: "none",
                cursor: "pointer",
                textAlign: "left",
                transition: "background-color 0.12s ease",
                borderBottom: i < arr.length - 1 ? "1px solid rgba(19,18,33,0.07)" : "none",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "rgba(19,18,33,0.03)")}
              onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
            >
              <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: "var(--text-sm)",
                    fontWeight: "var(--font-weight-medium)",
                    lineHeight: "20px",
                    color: "var(--accent)",
                  }}
                >
                  {label}
                </span>
                <span
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: "var(--text-xs)",
                    lineHeight: "16px",
                    color: "var(--muted-foreground)",
                  }}
                >
                  {sub}
                </span>
              </div>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginLeft: 8 }}>
                <path d="M6 3L11 8L6 13" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}